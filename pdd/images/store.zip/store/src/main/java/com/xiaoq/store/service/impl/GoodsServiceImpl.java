package com.xiaoq.store.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.RandomUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sun.org.apache.bcel.internal.generic.IF_ACMPEQ;
import com.xiaoq.store.entity.ShopGoods;
import com.xiaoq.store.exception.BusinessExceptions;
import com.xiaoq.store.mapper.ShopGoodsMapper;
import com.xiaoq.store.service.GoodsService;
import com.xiaoq.store.util.SystemCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Description:
 * @Author: x
 *
 */
@Service
public class GoodsServiceImpl extends ServiceImpl<ShopGoodsMapper, ShopGoods> implements GoodsService {
    @Autowired
    private ShopGoodsMapper shopGoodsMapper;

    /**
     * 跟进id获取商品信息
     * @param id
     * @return
     */
    @Override
    public ShopGoods goodsInfo(Long id) {
        ShopGoods shopGoods = shopGoodsMapper.selectById(id);
        if (BeanUtil.isEmpty(shopGoods)){
            throw new  BusinessExceptions("当前商品不存在", SystemCode.DATA_NOT_EXIST.getCode());
        }
        return shopGoods;
    }

    @Override
    public void saveGoods(ShopGoods shopGoods) {
        /**
         * 1.生成商品货号并对比已有商品 保证货号唯一性
         * 2.封装shopGoods
         * 3.保存商品信息
         */
        Long productSn;
        do {
            //生成一个12bit的用户Id
            productSn = RandomUtil.randomLong(100000000000L, 999999999999L);
            //查看userId是否存在
            ShopGoods goods = this.baseMapper
                    .selectOne(new QueryWrapper<ShopGoods>().eq("product_sn", productSn));
            if (BeanUtil.isEmpty(goods)) {
                break;
            }
        } while (true);
        // 货号 创建时间 等等
        shopGoods.setProductSn(productSn);
        int insert = this.baseMapper.insert(shopGoods);
        if (insert<1){
            throw new BusinessExceptions("商品新增失败");
        }
    }

    @Override
    public int deleteGoods(Long id) {
        ShopGoods shopGoods = shopGoodsMapper.selectById(id);
        if (BeanUtil.isEmpty(shopGoods)){
            throw new  BusinessExceptions("当前商品不存在", SystemCode.DATA_NOT_EXIST.getCode());
        }
        int i = shopGoodsMapper.deleteById(id);
        if (i <1){
            throw new BusinessExceptions("商品删除失败");
        }
        return i;
    }

    @Override
    public void updateGoodsStatus(List<Long> asList, Integer status) {
        List<ShopGoods> shopGoods = shopGoodsMapper.selectBatchIds(asList);
        if (CollectionUtil.isEmpty(shopGoods)){
            throw new BusinessExceptions("商品信息获取失败", SystemCode.DATA_NOT_EXIST.getCode());
        }
        for (ShopGoods shopGood : shopGoods) {
            shopGood.setStatus(status);
        }
        boolean update = this.updateBatchById(shopGoods);
        if (!update){
            //如需返回code 请自行补充
            throw new BusinessExceptions("修改商品状态失败");
        }
    }
}
