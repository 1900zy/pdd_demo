package com.xiaoq.store.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
 * shop_goods
 * @author 
 */
@Data
public class ShopGoods implements Serializable {
    /**
     * 商品表id 
     */
    private Integer id;

    /**
     * 商品名称
     */
    private String productName;

    /**
     * 商品货号
     */
    private Long productSn;

    /**
     * 商品描述
     */
    private String productDescribe;

    /**
     * 库存
     */
    private Integer inventory;

    /**
     * 价格
     */
    private BigDecimal price;

    /**
     * 原价
     */
    private BigDecimal originalPrice;

    /**
     * 主图
     */
    private String coverPic;

    /**
     * 预览图-缩略图
     */
    private String pics;

    /**
     * 上架状态
     */
    private Integer status;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 删除状态
     */
    private Byte deleted;

    private static final long serialVersionUID = 1L;
}