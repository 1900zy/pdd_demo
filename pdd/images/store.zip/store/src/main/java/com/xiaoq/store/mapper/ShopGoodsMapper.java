package com.xiaoq.store.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xiaoq.store.entity.ShopGoods;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;

/**
 * @author x
 */
@Repository
public interface ShopGoodsMapper extends BaseMapper<ShopGoods> {

}