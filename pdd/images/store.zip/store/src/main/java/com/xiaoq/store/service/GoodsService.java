package com.xiaoq.store.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xiaoq.store.entity.ShopGoods;

import java.util.List;

/**
 * @Description:
 * @Author: x
 *
 */
public interface GoodsService extends IService<ShopGoods> {
    /**
     * 该处应返回 ShopGoods实体对应的Vo 为了简便该处直接返回Entity
     * @param id
     * @return
     */
    ShopGoods goodsInfo(Long id);

    /**
     *
     * @param shopGoods
     */
    void saveGoods(ShopGoods shopGoods);

    /**
     *
     * @param id
     * @return
     */
    int deleteGoods(Long id);

    /**
     *
     * @param asList
     * @param status
     */
    void updateGoodsStatus(List<Long> asList, Integer status);
}
