package com.xiaoq.store.web.controller;

import com.xiaoq.store.entity.ShopGoods;
import com.xiaoq.store.service.GoodsService;
import com.xiaoq.store.util.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;

/**
 * @Description:
 * @Author: x
 * @Date :
 */
@RestController
@RequestMapping(value = "/goods")
@Api(tags = "商品")
public class GoodsController {

    @Autowired
    private GoodsService goodsService;

    @GetMapping("Info")
    @ApiOperation(value = "获取商品信息By Id")
    public Result getGoodsInfo(@ApiParam(value = "id" , required = true) Long id){
        ShopGoods shopGoods = goodsService.goodsInfo(id);
        return Result.succeed(shopGoods);
    }

    @GetMapping("add")
    @ApiOperation(value = "商品新增")
    public Result saveGoods(@RequestBody ShopGoods shopGoods){
        goodsService.saveGoods(shopGoods);
        return Result.succeed();
    }

    @DeleteMapping("delete")
    @ApiOperation(value = "商品删除By Id")
    public Result deleteGoods(@ApiParam(value = "id" , required = true) Long id){
        return Result.succeed(goodsService.deleteGoods(id));
    }

    @PutMapping("update")
    @ApiOperation(value = "批量修改商品上下架状态")
    public Result updateGoodsStatus(@RequestBody Long[] id, @RequestParam(value = "status") Integer status){
        goodsService.updateGoodsStatus(Arrays.asList(id),status);
        return Result.succeed();
    }

}
