/*
Navicat MySQL Data Transfer

Source Server         : xiaoq
Source Server Version : 50729
Source Host           : 150.158.107.10:3305
Source Database       : shop

Target Server Type    : MYSQL
Target Server Version : 50729
File Encoding         : 65001

Date: 2021-03-02 15:34:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for shop_goods
-- ----------------------------
DROP TABLE IF EXISTS `shop_goods`;
CREATE TABLE `shop_goods` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '商品表id ',
  `product_name` varchar(32) DEFAULT NULL COMMENT '商品名称',
  `product_sn` bigint(16) DEFAULT '0' COMMENT '商品货号',
  `product_describe` varchar(255) DEFAULT '' COMMENT '商品描述',
  `inventory` int(10) DEFAULT NULL COMMENT '库存',
  `price` decimal(10,2) DEFAULT NULL COMMENT '价格',
  `original_price` decimal(10,2) DEFAULT NULL COMMENT '原价',
  `cover_pic` varchar(255) DEFAULT NULL COMMENT '主图',
  `pics` varchar(512) DEFAULT NULL COMMENT '预览图-缩略图',
  `status` int(1) DEFAULT NULL COMMENT '上架状态',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(4) DEFAULT NULL COMMENT '删除状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
